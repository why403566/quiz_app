eximport 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pakistan Quiz Pro',
      theme: ThemeData(primarySwatch: Colors.green, brightness: Brightness.dark, useMaterial3: true),
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// HOME SCREEN
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map highScores = {'GK':0, 'Science':0, 'Islam':0};

  @override
  void initState(){ super.initState(); loadScores(); }

  loadScores() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState((){
      highScores['GK'] = prefs.getInt('high_GK')?? 0;
      highScores['Science'] = prefs.getInt('high_Science')?? 0;
      highScores['Islam'] = prefs.getInt('high_Islam')?? 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("🇵🇰 Pakistan Quiz Pro 🔊"), centerTitle: true),
      body: Column(children:[
        SizedBox(height: 20),
        Text("Category Select Karein", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        Expanded(child: ListView(
          children: ["GK","Science","Islam"].map((cat) =>
            Card(margin: EdgeInsets.all(12),
              child: ListTile(
                leading: CircleAvatar(child: Text(cat[0])),
                title: Text("$cat Quiz", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                subtitle: Text("High Score: ${highScores[cat]}/5 | Total: 40 Sawal"),
                trailing: ElevatedButton(child: Text("Start"), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(category: cat))).then((_)=>loadScores())),
              ),
            )
          ).toList(),
        ))
      ]),
    );
  }
}

// QUIZ SCREEN
class QuizScreen extends StatefulWidget {
  final String category;
  QuizScreen({required this.category});
  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int q = 0, score = 0, timer = 10, lives = 3;
  Timer? _timer;
  bool answered = false;
  List questions = [];
  final player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    questions = allQuestions.where((x) => x['cat'] == widget.category).toList();
    questions.shuffle(Random());
    questions = questions.take(5).toList(); // Har level 5 sawal
    startTimer();
  }

  void playSound(bool sahi) async {
    if(sahi){ await player.play(AssetSource('correct.mp3')); }
    else { await player.play(AssetSource('wrong.mp3')); }
  }

  void startTimer() {
    timer = 10; answered = false;
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 1), (t) {
      setState(() {
        if (timer > 0 &&!answered) timer--;
        else { t.cancel(); if(!answered) wrongAns(); }
      });
    });
  }

  void checkAns(int i) {
    if(answered) return;
    answered = true; _timer?.cancel();
    if(i == questions[q]['correct']) { score++; playSound(true); }
    else { playSound(false); wrongAns(); return; }
    Future.delayed(Duration(milliseconds: 1000), nextQuestion);
  }

  void wrongAns(){
    setState((){
      lives--;
      if(lives <= 0) showResult();
      else Future.delayed(Duration(milliseconds: 1000), nextQuestion);
    });
  }

  void nextQuestion() {
    setState(() {
      if(q < questions.length - 1) { q++; startTimer(); }
      else { showResult(); }
    });
  }

  void showResult() async {
    _timer?.cancel();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int oldHigh = prefs.getInt('high_${widget.category}')?? 0;
    if(score > oldHigh) prefs.setInt('high_${widget.category}', score);

    showDialog(context: context, barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text("Quiz Khatam 🎉"),
        content: Text("Aapka Score: $score/5\n\n${score == 5? 'Shabash Champion! 🏆' : score>=3? 'Acha Khela!' : 'Dobara try karo'}"),
        actions: [TextButton(onPressed: (){Navigator.pop(context); Navigator.pop(context);}, child: Text("Menu Pe Jao"))],
      )
    );
  }

  @override
  void dispose() { player.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("${widget.category} - Level 1"), actions: [
        Padding(padding: EdgeInsets.all(10), child: Row(children:[
          Icon(Icons.favorite, color: Colors.red), Text(" $lives | "),
          Icon(Icons.timer), Text(" $timer s")
        ]))
      ]),
      body: Padding(padding: EdgeInsets.all(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          LinearProgressIndicator(value: (q+1)/questions.length, minHeight: 8),
          SizedBox(height: 10),
          Text("Sawal ${q+1}/5", style: TextStyle(fontSize: 16, color: Colors.grey)),
          SizedBox(height: 10),
          if(questions[q]['img']!= "")
            Center(child: ClipRRect(borderRadius: BorderRadius.circular(10),child: Image.network(questions[q]['img'], height: 160, fit: BoxFit.cover, errorBuilder:(_,__,___)=>SizedBox()))),
          SizedBox(height: 15),
          Text(questions[q]['que'], style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          SizedBox(height: 25),
        ...List.generate(questions[q]['ans'].length, (i) =>
            Container(width: double.infinity, margin: EdgeInsets.only(bottom: 12),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(padding: EdgeInsets.all(16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                onPressed: () => checkAns(i),
                child: Text(questions[q]['ans'][i], style: TextStyle(fontSize: 17))
              )
            )
          ),
          Spacer(),
          Center(child: Text("Score: $score", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))
        ]),
      ),
    );
  }
}

// ===== 120 SAWAL - 40 GK + 40 SCIENCE + 40 ISLAM =====
var allQuestions = [
  // GK 40
  {'que': 'Pakistan ka Capital kya hai?', 'ans': ['Karachi', 'Islamabad', 'Lahore'], 'correct': 1, 'cat': 'GK', 'img': 'https://upload.wikimedia.org/wikipedia/commons/8/82/Faisal_Mosque%2C_Islamabad_-_Pakistan.jpg'},
  {'que': 'Pakistan ka qomi darakht?', 'ans': ['Deodar', 'Neem', 'Keekar'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Duniya ki sabse unchi choti?', 'ans': ['K2', 'Mount Everest', 'Nanga Parbat'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan mein kitne soobe hain?', 'ans': ['3', '4', '5'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Quaid-e-Azam ka yaum-e-wafat?', 'ans': ['11 Sep', '14 Aug', '23 Mar'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ka qomi phool?', 'ans': ['Gulab', 'Chameli', 'Motia'], 'correct': 2, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ki sabse lambi nadi?', 'ans': ['Ravi', 'Sindh', 'Jhelum'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ka qomi khel?', 'ans': ['Cricket', 'Hockey', 'Football'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Minar-e-Pakistan kahan hai?', 'ans': ['Karachi', 'Lahore', 'Islamabad'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ki currency?', 'ans': ['Rupya', 'Dollar', 'Riyal'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan kab azaad hua?', 'ans': ['1947', '1950', '1965'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Badshahi Masjid kahan hai?', 'ans': ['Multan', 'Lahore', 'Peshawar'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Karakoram Highway kis mulk ko milati hai?', 'ans': ['Iran', 'China', 'Afghanistan'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ka qomi janwar?', 'ans': ['Sher', 'Markhor', 'Hiran'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Gwadar Port kis samandar par hai?', 'ans': ['Arab', 'Indian', 'Pacific'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ka sabse bara shehar?', 'ans': ['Lahore', 'Karachi', 'Islamabad'], 'correct': 1, 'cat': 'GK', 'img': ''},
  {'que': 'Allama Iqbal ka mazar kahan hai?', 'ans': ['Lahore', 'Karachi', 'Multan'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ka qomi geet kisne likha?', 'ans': ['Hafeez Jalandhari', 'Allama Iqbal', 'Faiz'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Tarbela Dam kis nadi par hai?', 'ans': ['Sindh', 'Jhelum', 'Chenab'], 'correct': 0, 'cat': 'GK', 'img': ''},
  {'que': 'Pakistan ka qomi phal?', 'ans': ['Aam', 'Seb', 'Angoor'], 'correct': 0, 'cat': 'GK', 'img': ''},
  
Question("Pakistan ka dar-ul-hakumat?",["Karachi","Islamabad","Lahore","Multan"],1),
Question("Duniya ka sab se bara ocean?",["Atlantic","Indian","Pacific","Arctic"],2),
Question("Quran me total Suratain?",["114","110","112","115"],0),
Question("Computer ka dimagh kise kehte hain?",["RAM","CPU","Mouse","Keyboard"],1),
Question("Pakistan ka qaumi khel?",["Cricket","Hockey","Football","Squash"],1),
Question("Light ki speed?",["3 lakh km/s","1 lakh km/s","5 lakh km/s","2 lakh km/s"],0),
Question("Taj Mahal kahan hai?",["Pakistan","India","Turkey","Iran"],1),
Question("WWW ka matlab?",["World Wide Web","World War Web","Wide World Web","Web Wide World"],0),
Question("Insan ke kitne daant hote hain?",["32","28","30","26"],0),
Question("Blood ka color kyun red hota hai?",["Iron","Water","Calcium","Hemoglobin"],3),
Question("Pakistan kab azad hua?",["1947","1945","1948","1950"],0),
Question("Islam ke kitne arkan hain?",["4","5","6","3"],1),
Question("Duniya ka sab se uncha pahar?",["K2","Everest","Nanga Parbat","Alps"],1),
Question("Google kis mulk ki company hai?",["USA","UK","China","Japan"],0),
Question("1 GB =?",["1000 MB","1024 MB","512 MB","2048 MB"],1),
Question("Sun kis simt se nikalta hai?",["East","West","North","South"],0),
Question("Pakistan ka qaumi phool?",["Rose","Jasmine","Sunflower","Lily"],1),
Question("Human heart kitne chambers ka hota hai?",["2","3","4","5"],2),
Question("Islamabad se pehle capital kaunsa tha?",["Lahore","Karachi","Multan","Peshawar"],1),
Question("Flutter kis language me banta hai?",["Java","Kotlin","Dart","Python"],2),


  // SCIENCE 40
  {'que': 'Insan ke jism mein kitni haddiyan?', 'ans': ['206', '208', '210'], 'correct': 0, 'cat': 'Science', 'img': ''},
  {'que': 'Pani ka chemical formula?', 'ans': ['H2O', 'CO2', 'O2'], 'correct': 0, 'cat': 'Science', 'img': ''},
  {'que': 'Suraj ek sitara hai ya siyara?', 'ans': ['Sitara', 'Siyara', 'Dono'], 'correct': 0, 'cat': 'Science', 'img': 'https://upload.wikimedia.org/wikipedia/commons/b/b4/The_Sun_by_the_Atmospheric_Imaging_Assembly_of_NASA%27s_Solar_Dynamics_Observatory_-_20100819.jpg'},
  {'que': 'Bijli ka unit kya hai?', 'ans': ['Volt', 'Ampere', 'Watt'], 'correct': 2, 'cat': 'Science', 'img': ''},
  {'que': 'Dil jism ke kis taraf hota hai?', 'ans': ['Dain', 'Bain', 'Beech'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Zameen ko suraj ka chakkar lagane mein kitna time?', 'ans': ['24 ghante', '30 din', '365 din'], 'correct': 2, 'cat': 'Science', 'img': ''},
  {'que': 'Oxygen ka formula?', 'ans': ['O', 'O2', 'O3'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Machli saans kisse leti hai?', 'ans': ['Naak', 'Gill', 'Muh'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Sabse sakht cheez?', 'ans': ['Loha', 'Heera', 'Sona'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Doodh se kya banta hai?', 'ans': ['Protein', 'Calcium', 'Iron'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Roshni ki speed?', 'ans': ['3 lakh km/s', '1 lakh km/s', '5 lakh km/s'], 'correct': 0, 'cat': 'Science', 'img': ''},
  {'que': 'Dimag ka wazan kitna hota hai?', 'ans': ['1 kg', '1.4 kg', '2 kg'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Phone kis energy se chalta hai?', 'ans': ['Solar', 'Battery', 'Gas'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Sabse bara siyara?', 'ans': ['Zameen', 'Mushtari', 'Zuhal'], 'correct': 1, 'cat': 'Science', 'img': ''},
  {'que': 'Baraf pani mein kyun tairti hai?', 'ans': ['Halki hoti', 'Bharti hoti', 'Garm hoti'], 'correct': 0, 'cat': 'Science', 'img': ''},
  
Question("Insan kitni hadiyon par mushtamil hai?",["206","300","150","2060"],0),
Question("Khoon ka rang laal kyun hota hai?",["Plasma","Hemoglobin","Platelets","WBC"],1),
Question("Pani ka chemical formula?",["H2O","CO2","O2","NaCl"],0),
Question("Dil 1 minute me kitni baar dharakta hai?",["72","100","60","120"],0),
Question("Light ki speed sab se tez kis me hai?",["Pani","Hawa","Vacuum","Kaanch"],2),
Question("Insan ke dimagh ka wazan?",["1kg","1.4kg","2kg","500g"],1),
Question("Kaunsa planet sab se bara hai?",["Earth","Jupiter","Saturn","Mars"],1),
Question("Oxygen kis ne daryaft ki?",["Newton","Priestley","Einstein","Edison"],1),
Question("DNA ka full form?",["Deoxyribonucleic Acid","Data Acid","Double Acid","Dir Acid"],0),
Question("Insan kitni % paani par hai?",["50%","70%","90%","30%"],1),
Question("Bijli ka unit kya hai?",["Watt","Volt","Ampere","Ohm"],0),
Question("Kaunsa gas saans lene ke liye zaroori hai?",["CO2","O2","Nitrogen","Hydrogen"],1),
Question("Chand par gravity zameen se kitni hai?",["1/6","1/2","1/4","Same"],0),
Question("Solar system me kitne planets hain?",["8","9","7","10"],0),
Question("Khana hazam kahan hota hai?",["Stomach","Small Intestine","Liver","Mouth"],1),
Question("Vitamin C kis me sab se zyada?",["Apple","Orange","Banana","Potato"],1),
Question("Atom ka markaz kya kehlata hai?",["Electron","Nucleus","Proton","Neutron"],1),
Question("Sound sab se tez kis me safar karti hai?",["Hawa","Pani","Loha","Vacuum"],2),
Question("Rainbow me kitne rang?",["5","6","7","8"],2),
Question("Bacteria ko kis ne dekha?",["Leeuwenhoek","Newton","Pasteur","Darwin"],0),
Question("Insan ke khoon ka pH?",["7.4","6.5","8.0","5.5"],0),
Question("Zameen gol hai ye kis ne kaha?",["Aristotle","Newton","Pythagoras","Galileo"],2),
Question("Electric bulb kis ne ijad kiya?",["Edison","Tesla","Newton","Einstein"],0),
Question("Kaunsa vitamin dhoop se milta hai?",["A","B","C","D"],3),
Question("Force ka unit?",["Newton","Joule","Watt","Pascal"],0),


  // ISLAM 40
  {'que': 'Quran Pak mein kitne Surah hain?', 'ans': ['110', '114', '120'], 'correct': 1, 'cat': 'Islam', 'img': 'https://upload.wikimedia.org/wikipedia/commons/4/4b/Quran.jpg'},
  {'que': 'Pehla Nabi kaun the?', 'ans': ['Hazrat Musa', 'Hazrat Adam', 'Hazrat Isa'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Kaba kis shehar mein hai?', 'ans': ['Madina', 'Makkah', 'Karachi'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Roza kis mahine mein farz hai?', 'ans': ['Rajab', 'Ramzan', 'Shaban'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Islam ka pehla rukan?', 'ans': ['Namaz', 'Kalma', 'Zakat'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Quran Pak kis zaban mein nazil hua?', 'ans': ['Urdu', 'Arbi', 'Farsi'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': '5 Namazon mein sabse pehli Namaz?', 'ans': ['Zohar', 'Fajr', 'Asar'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Ghazwa-e-Badr mein kitne musalman the?', 'ans': ['313', '1000', '500'], 'correct': 0, 'cat': 'Islam', 'img': ''},
  {'que': 'Jannat ke darwaze kitne hain?', 'ans': ['7', '8', '9'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Hazrat Muhammad SAW ki paidaish?', 'ans': ['570', '610', '632'], 'correct': 0, 'cat': 'Islam', 'img': ''},
  {'que': 'Pehli wahi kahan nazil hui?', 'ans': ['Ghar-e-Hira', 'Masjid-e-Nabvi', 'Kaba'], 'correct': 0, 'cat': 'Islam', 'img': ''},
  {'que': 'Hazrat Ayesha RA kis ki beti theen?', 'ans': ['Hazrat Umar', 'Hazrat Abu Bakar', 'Hazrat Usman'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Quran Pak mein sabse bara Surah?', 'ans': ['Al-Baqarah', 'Al-Imran', 'Yaseen'], 'correct': 0, 'cat': 'Islam', 'img': ''},
  {'que': 'Islam mein kitne farz hain?', 'ans': ['4', '5', '6'], 'correct': 1, 'cat': 'Islam', 'img': ''},
  {'que': 'Hazrat Musa AS ka moujza?', 'ans': ['Asa', 'Ungli', 'Quran'], 'correct': 0, 'cat': 'Islam', 'img': ''},
  
Question("Quran me kul kitni Suratain hain?",["110","114","112","116"],1),
Question("Quran ka pehla lafz jo nazil hua?",["Iqra","Alhamd","Bismillah","Qul"],0),
Question("Namaz din me kitni farz hain?",["4","5","6","3"],1),
Question("Roza kis mahine me farz hai?",["Rajab","Shaban","Ramzan","Muharram"],2),
Question("Kaaba kahan hai?",["Madina","Makkah","Quds","Baghdad"],1),
Question("Hazrat Muhammad SAW ki hijrat kahan hui?",["Taif se Makkah","Makkah se Madina","Madina se Makkah","Yemen se Makkah"],1),
Question("Azaan me kitne kalmay hain?",["12","15","10","7"],1),
Question("Quran ka sab se lamba Surah?",["Al-Baqarah","Al-Imran","Nisa","Maida"],0),
Question("Islam ke arkan kitne hain?",["4","5","6","7"],1),
Question("Jang-e-Badr kab hui?",["2 Hijri","3 Hijri","4 Hijri","1 Hijri"],0),
Question("Hazrat Ali RA ka laqab?",["Farooq","Siddiq","Haider","Ghani"],2),
Question("Quran me kul kitne paray hain?",["28","30","32","34"],1),
Question("Sab se pehle Wahi lane wale farishte?",["Israfil AS","Jibrail AS","Mikail AS","Izrail AS"],1),
Question("Namaz-e-Janaza me kitni takbeerein?",["3","4","5","6"],1),
Question("Hajj kis mahine me hota hai?",["Shawwal","Zil Hajj","Muharram","Ramzan"],1),
Question("Zakat ka nisab sona kitna?",["7.5 Tola","5 Tola","10 Tola","2.5 Tola"],0),
Question("Quran ka dil kis Surah ko kaha gaya?",["Yaseen","Rahman","Mulk","Fatiha"],0),
Question("Hazrat Muhammad SAW ki wiladat kab hui?",["12 Rabi-ul-Awwal","10 Muharram","27 Rajab","1 Shawwal"],0),
Question("Kalma Tayyab me kitne kalmay?",["1","2","4","6"],0),
Question("Quran kitne arse me nazil hua?",["23 Saal","20 Saal","25 Saal","30 Saal"],0),
Question("Ashra Mubashra kitne sahaba hain?",["5","10","12","8"],1),
Question("Sab se chhota Surah?",["Kausar","Ikhlas","Asr","Nasr"],0),
Question("Tahajjud ki namaz ka waqt?",["Fajar ke baad","Isha ke baad raat ka akhri hissa","Maghrib ke baad","Zohar se pehle"],1),
Question("Wazu me kitne farz hain?",["3","4","5","6"],1),
Question("Miraj ka zikr kis Surah me hai?",["Surah Bani Israil","Surah Najam","Dono me","Surah Baqarah"],2),
];
